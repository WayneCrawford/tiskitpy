"""
Spectral toolbox
"""
from .spectral_density import SpectralDensity
from .Peterson_noise_model import Peterson_noise_model